import streamlit as st
import json
import hashlib
import time
import os

# ---------------------- Block & Blockchain Classes ----------------------
class Block:
    def __init__(self, index, voter_hash, state, district, party, previous_hash):
        self.index = index
        self.timestamp = time.time()
        self.voter_hash = voter_hash
        self.state = state
        self.district = district
        self.party = party
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        data = f"{self.index}{self.timestamp}{self.voter_hash}{self.state}{self.district}{self.party}{self.previous_hash}"
        return hashlib.sha256(data.encode()).hexdigest()

    def to_dict(self):
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "voter_hash": self.voter_hash,
            "state": self.state,
            "district": self.district,
            "party": self.party,
            "previous_hash": self.previous_hash,
            "hash": self.hash
        }

class Blockchain:
    def __init__(self):
        self.chain = []
        self.load_chain()

    def create_genesis_block(self):
        genesis = Block(0, "GENESIS", "None", "None", "None", "0")
        self.chain.append(genesis)

    def add_vote(self, voter_id, state, district, party):
        if not self.chain:
            self.create_genesis_block()
        prev = self.chain[-1]
        voter_hash = hashlib.sha256(voter_id.encode()).hexdigest()
        new_block = Block(len(self.chain), voter_hash, state, district, party, prev.hash)
        self.chain.append(new_block)

    def save_chain(self, filename="blockchain.json"):
        with open(filename, "w") as f:
            json.dump([b.to_dict() for b in self.chain], f, indent=4)

    def load_chain(self, filename="blockchain.json"):
        try:
            with open(filename, "r") as f:
                data = json.load(f)
                self.chain = []
                for b in data:
                    block = Block(
                        index=b["index"],
                        voter_hash=b["voter_hash"],
                        state=b["state"],
                        district=b["district"],
                        party=b["party"],
                        previous_hash=b["previous_hash"]
                    )
                    block.timestamp = b["timestamp"]
                    block.hash = b["hash"]
                    self.chain.append(block)
        except:
            self.create_genesis_block()

# ---------------------- Utility Functions ----------------------
def load_voters():
    if os.path.exists("voter_list.json"):
        with open("voter_list.json", "r") as f:
            return json.load(f)
    return {}

def save_voters(voters):
    with open("voter_list.json", "w") as f:
        json.dump(voters, f, indent=4)

def load_admin():
    path = "admin_credentials.json"
    if os.path.exists(path):
        with open(path, "r") as f:
            try:
                data = json.load(f)
                return data
            except json.JSONDecodeError:
                pass  # fallback to recreate default below
    # default fallback
    data = {"admin": "password123"}
    with open(path, "w") as f:
        json.dump(data, f, indent=4)
    return data


# ---------------------- Initialize Blockchain & State ----------------------
blockchain = Blockchain()
voters = load_voters()
admin_credentials = load_admin()

# ---------------------- Session State Init ----------------------
if "admin_logged_in" not in st.session_state:
    st.session_state.admin_logged_in = False

# ---------------------- Candidate Image Paths ----------------------
party_images = {
    "BJP": "C:/Users/ambil/OneDrive/Desktop/blockchain-voting-system/images/BJP image.webp",
    "LDF": "C:/Users/ambil/OneDrive/Desktop/blockchain-voting-system/images/LDF image.jpg",
    "UDF": "C:/Users/ambil/OneDrive/Desktop/blockchain-voting-system/images/UDF image.jpg"
}

# ---------------------- Streamlit Interface ----------------------
st.title("🗳 Blockchain-Based Voting System")

login_type = st.radio("Select user type", ["Voter", "Admin"])

# ---------------------- Voter Panel ----------------------
if login_type == "Voter":
    st.subheader("Voter Panel")
    unique_id = st.text_input("Enter your Unique Voter ID")
    if unique_id:
        if unique_id in voters:
            st.success(f"Welcome {voters[unique_id]['name']}")
            state = voters[unique_id]["state"]
            district = voters[unique_id]["district"]
            st.write(f"State: {state}, District: {district}")

            already_voted = any(
                hashlib.sha256(unique_id.encode()).hexdigest() == block.voter_hash
                for block in blockchain.chain
            )
            if already_voted:
                st.warning("You have already cast your vote.")
            else:
                party = st.radio("Choose your party", list(party_images.keys()))
                if party:
                    st.image(party_images[party], caption=f"Candidate of {party}", width=200)

                if st.button("Cast Vote"):
                    blockchain.add_vote(unique_id, state, district, party)
                    blockchain.save_chain()
                    st.success("✅ Your vote has been recorded successfully!")
        else:
            st.error("❌ You are not a registered voter. Please contact the admin.")

# ---------------------- Admin Panel ----------------------
elif login_type == "Admin":
    st.subheader("Admin Login")

    if not st.session_state.admin_logged_in:
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login"):
            if username in admin_credentials and admin_credentials[username] == password:
                st.session_state.admin_logged_in = True
                st.success("✅ Logged in as Admin")
                st.rerun()
            else:
                st.error("❌ Invalid admin credentials")

    if st.session_state.admin_logged_in:
        st.success("✅ Logged in as Admin")
        menu = st.radio("Choose an action", ["View Vote Count", "Add Voter"])

        if menu == "View Vote Count":
            import pandas as pd
            df = pd.DataFrame([
                {
                    "state": b.state,
                    "district": b.district,
                    "party": b.party
                }
                for b in blockchain.chain if b.index > 0
            ])
            if not df.empty:
                result = df.groupby(["state", "district", "party"]).size().reset_index(name="Votes")
                st.dataframe(result)
            else:
                st.info("📭 No votes cast yet.")

        elif menu == "Add Voter":
            st.subheader("Register New Voter")
            name = st.text_input("Voter's Full Name")
            uid = st.text_input("Unique Voter ID")
            state = st.text_input("State")
            district = st.text_input("District")

            if st.button("Add Voter"):
                if uid not in voters:
                    voters[uid] = {"name": name, "state": state, "district": district}
                    save_voters(voters)
                    st.success(f"✅ Voter '{name}' added successfully!")
                else:
                    st.warning("⚠️ Voter already exists!")

        if st.button("Logout"):
            st.session_state.admin_logged_in = False
            st.rerun()
